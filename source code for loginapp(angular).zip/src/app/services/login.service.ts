import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  url="http://localhost:8080"

  constructor(private http:HttpClient) { }

  //calling the server to generate token

  generateToken(credentials:any){
    //token generate

    return this.http.post(`${this.url}/token`,credentials)
  }



  //for login user

  loginuser(token:any){

    localStorage.setItem("token",token)
    return true;
  }


  //to check user is logged in or not
  // isLoggedIn(){
  //  let token = localStorage.getItem("token");

  // // return token !== undefined && token !== '' && token !== null;

  //  if(token!==undefined || token!=='' || token!==null){
  //   return true;

  //  }else{

  //   return false;
  //  }


  // }


  isLoggedIn() {
    if (typeof window !== 'undefined' && typeof window.localStorage !== 'undefined') {
      const token = localStorage.getItem("token");
      return token !== undefined && token !== '';
    } else {
      // Handle server-side or other cases without localStorage
      // For example, you could return a default value or communicate with a server-side store:
      return this.http.get<boolean>(`${this.url}`);
    }
  }

  //to logout the user
  logout(){
    localStorage.removeItem('token')
    return true;
  }

  getToken(){
    return localStorage.getItem("token")
  }


}
